token_name = "HXRP"
hex_code = token_name.encode("utf-8").hex().upper()
print(hex_code)
