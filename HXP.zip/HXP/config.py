# config.py
XRPL_NETWORK = "https://s.altnet.rippletest.net:51234"  # Use XRP Testnet URL
ISSUER_SEED = "sEd7PXZaTMo6cNSaJxJKssn2KabuNTS"
ISSUER_ADDRESS = "rwYciXXMeWwNaHpLucC8B75hKoSmzQT2kx"
HXRP_CURRENCY = "48585250"  # HEX for HXRP (e.g., 'HXRP' converted to HEX)

